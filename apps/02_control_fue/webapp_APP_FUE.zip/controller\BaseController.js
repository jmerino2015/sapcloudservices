sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/m/MessageBox",
  "sap/m/MessageToast"
], function (Controller, MessageBox, MessageToast) {
  "use strict";

  return Controller.extend("fue.control.controller.BaseController", {
    
    /**
     * Helper to get a model from the component or view
     * @param {string} [sName] Model name
     * @returns {sap.ui.model.Model}
     */
    getModel: function (sName) {
      return this.getView().getModel(sName) || this.getOwnerComponent().getModel(sName);
    },

    /**
     * Helper to set a model on the view
     * @param {sap.ui.model.Model} oModel Model instance
     * @param {string} [sName] Model name
     */
    setModel: function (oModel, sName) {
      this.getView().setModel(oModel, sName);
    },

    /**
     * Helper to get the resource bundle
     * @returns {sap.base.i18n.ResourceBundle}
     */
    getResourceBundle: function () {
      return this.getOwnerComponent().getModel("i18n").getResourceBundle();
    },

    /**
     * Translate text
     * @param {string} sKey
     * @param {any[]} [aArgs]
     * @returns {string}
     */
    getText: function (sKey, aArgs) {
      return this.getResourceBundle().getText(sKey, aArgs);
    },

    /**
     * Display a success MessageToast or box
     * @param {string} sMessage
     */
    showSuccess: function (sMessage) {
      MessageToast.show(sMessage);
    },

    /**
     * Display an error MessageBox
     * @param {string} sMessage
     */
    showError: function (sMessage) {
      MessageBox.error(sMessage);
    },

    /**
     * Recalculates KPIs and Pivot Matrix from raw FUE records
     * @param {any[]} [aRecords] Optional new records list
     */
    updatePivotAndKpis: function (aRecords) {
      var oModel = this.getModel("fueModel");
      if (!aRecords) {
        aRecords = oModel.getProperty("/records") || [];
      } else {
        oModel.setProperty("/records", aRecords);
      }
      
      var nTotalFUE = 0;
      var nTotalUsers = aRecords.length;
      var nAdvanced = 0;
      var nCore = 0;
      var nDeveloper = 0;
      var nSelfService = 0;
      var oEmpresasSet = {};
      var sPeriod = "";

      // Aggregate KPIs
      aRecords.forEach(function (row) {
        var val = parseFloat(row.Fue) || 0;
        nTotalFUE += val;
        
        if (row.TipoFue === "Advanced") nAdvanced += val;
        else if (row.TipoFue === "Core") nCore += val;
        else if (row.TipoFue === "Developer") nDeveloper += val;
        else if (row.TipoFue === "Self Service") nSelfService += val;
        
        if (row.Empresa) {
          oEmpresasSet[row.Empresa] = true;
        }
        if (row.Periodo && !sPeriod) {
          sPeriod = row.Periodo;
        }
      });
      
      var nCompanies = Object.keys(oEmpresasSet).length;
      
      oModel.setProperty("/kpis/totalFUE", parseFloat(nTotalFUE.toFixed(2)));
      oModel.setProperty("/kpis/totalUsers", nTotalUsers);
      oModel.setProperty("/kpis/advancedFUE", parseFloat(nAdvanced.toFixed(2)));
      oModel.setProperty("/kpis/coreFUE", parseFloat(nCore.toFixed(2)));
      oModel.setProperty("/kpis/developerFUE", parseFloat(nDeveloper.toFixed(2)));
      oModel.setProperty("/kpis/selfServiceFUE", parseFloat(nSelfService.toFixed(2)));
      oModel.setProperty("/kpis/companiesCount", nCompanies);
      oModel.setProperty("/kpis/period", sPeriod || "Abril 2026");

      // Root KPI bindings for reliability
      oModel.setProperty("/totalFUE", parseFloat(nTotalFUE.toFixed(2)));
      oModel.setProperty("/totalUsers", nTotalUsers);
      oModel.setProperty("/advancedFUE", parseFloat(nAdvanced.toFixed(2)));
      oModel.setProperty("/coreFUE", parseFloat(nCore.toFixed(2)));
      oModel.setProperty("/developerFUE", parseFloat(nDeveloper.toFixed(2)));
      oModel.setProperty("/selfServiceFUE", parseFloat(nSelfService.toFixed(2)));
      oModel.setProperty("/companiesCount", nCompanies);
      oModel.setProperty("/period", sPeriod || "Abril 2026");

      console.log("DEBUG KPIs - Total:", nTotalFUE, "Users:", nTotalUsers, "Advanced:", nAdvanced, "Core:", nCore, "Developer:", nDeveloper, "SelfService:", nSelfService);

      // Build Pivot Matrix
      var aEmpresas = Object.keys(oEmpresasSet).sort();
      var aPivotData = [];
      var oGrandTotal = {
        Empresa: "Total general",
        Advanced: 0,
        Core: 0,
        Developer: 0,
        SelfService: 0,
        Total: 0,
        isTotalRow: true
      };
      
      aEmpresas.forEach(function (emp) {
        var oRow = {
          Empresa: emp,
          Advanced: 0,
          Core: 0,
          Developer: 0,
          SelfService: 0,
          Total: 0,
          isTotalRow: false
        };
        
        aRecords.forEach(function (rec) {
          if (rec.Empresa === emp) {
            var val = parseFloat(rec.Fue) || 0;
            if (rec.TipoFue === "Advanced") oRow.Advanced += val;
            else if (rec.TipoFue === "Core") oRow.Core += val;
            else if (rec.TipoFue === "Developer") oRow.Developer += val;
            else if (rec.TipoFue === "Self Service") oRow.SelfService += val;
            
            oRow.Total += val;
          }
        });
        
        // Round to 2 decimals
        oRow.Advanced = oRow.Advanced ? parseFloat(oRow.Advanced.toFixed(2)) : 0;
        oRow.Core = oRow.Core ? parseFloat(oRow.Core.toFixed(2)) : 0;
        oRow.Developer = oRow.Developer ? parseFloat(oRow.Developer.toFixed(2)) : 0;
        oRow.SelfService = oRow.SelfService ? parseFloat(oRow.SelfService.toFixed(2)) : 0;
        oRow.Total = parseFloat(oRow.Total.toFixed(2));
        
        // Add to grand total
        oGrandTotal.Advanced += oRow.Advanced;
        oGrandTotal.Core += oRow.Core;
        oGrandTotal.Developer += oRow.Developer;
        oGrandTotal.SelfService += oRow.SelfService;
        oGrandTotal.Total += oRow.Total;
        
        aPivotData.push(oRow);
      });
      
      // Round grand total to 2 decimals
      oGrandTotal.Advanced = parseFloat(oGrandTotal.Advanced.toFixed(2));
      oGrandTotal.Core = parseFloat(oGrandTotal.Core.toFixed(2));
      oGrandTotal.Developer = parseFloat(oGrandTotal.Developer.toFixed(2));
      oGrandTotal.SelfService = parseFloat(oGrandTotal.SelfService.toFixed(2));
      oGrandTotal.Total = parseFloat(oGrandTotal.Total.toFixed(2));
      
      // Append grand total row
      aPivotData.push(oGrandTotal);
      
      oModel.setProperty("/pivot", aPivotData);

      // Filter out total row for chart data and assign dynamic colors
      var aColors = ["Error", "Good", "Critical", "Neutral", "Good"];
      var aChartData = aPivotData.filter(function (row) {
        return !row.isTotalRow;
      }).map(function (row, idx) {
        row.color = aColors[idx % aColors.length];
        return row;
      });
      oModel.setProperty("/chartData", aChartData);

      // Create segments for license donut chart
      var aSegments = [
        { label: "Advanced", value: oGrandTotal.Advanced, color: "Error" },
        { label: "Core", value: oGrandTotal.Core, color: "Good" },
        { label: "Developer", value: oGrandTotal.Developer, color: "Neutral" },
        { label: "Self Service", value: oGrandTotal.SelfService, color: "Critical" }
      ];
      oModel.setProperty("/licenseSegments", aSegments);
    },

    /**
     * Downloads the pivot Excel file from the backend
     */
    onDownloadExcel: function () {
      var oModel = this.getModel("fueModel");
      var aRecords = oModel.getProperty("/records") || [];
      var oView = this.getView();
      
      oView.setBusy(true);

      fetch('/api/export-excel', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ data: aRecords })
      })
      .then(function (response) {
        if (!response.ok) throw new Error('Error al exportar Excel');
        return response.blob();
      })
      .then(function (blob) {
        oView.setBusy(false);
        var url = window.URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'Resumen_FUE.xlsx';
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
        MessageToast.show("Reporte Excel Pivot descargado con éxito.");
      })
      .catch(function (error) {
        oView.setBusy(false);
        MessageBox.error("Error al descargar Excel: " + error.message);
      });
    }
  });
});
