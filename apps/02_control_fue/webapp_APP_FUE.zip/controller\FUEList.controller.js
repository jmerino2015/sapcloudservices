sap.ui.define([
  "fue/control/controller/BaseController",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/m/MessageBox",
  "sap/m/Dialog",
  "sap/m/Button",
  "sap/m/Label",
  "sap/m/Input",
  "sap/m/Select",
  "sap/ui/core/Item",
  "sap/ui/layout/form/SimpleForm"
], function (BaseController, Filter, FilterOperator, MessageBox, Dialog, Button, Label, Input, Select, Item, SimpleForm) {
  "use strict";

  return BaseController.extend("fue.control.controller.FUEList", {
    
    onInit: function () {
      // Binding to table will reflect automatically
    },

    /**
     * Combines search field and dropdowns to filter the table
     */
    onSearch: function () {
      var sQuery = this.byId("searchUser").getValue();
      var sCompany = this.byId("filterCompany").getSelectedKey();
      var sType = this.byId("filterType").getSelectedKey();
      
      var aFilters = [];
      
      if (sQuery) {
        aFilters.push(new Filter({
          filters: [
            new Filter("Usuarios", FilterOperator.Contains, sQuery),
            new Filter("NombreCompleto", FilterOperator.Contains, sQuery)
          ],
          and: false
        }));
      }
      
      if (sCompany) {
        aFilters.push(new Filter("Empresa", FilterOperator.EQ, sCompany));
      }
      
      if (sType) {
        aFilters.push(new Filter("TipoFue", FilterOperator.EQ, sType));
      }
      
      var oTable = this.byId("fueTable");
      var oBinding = oTable.getBinding("items");
      if (oBinding) {
        oBinding.filter(aFilters);
      }
    },

    /**
     * Refreshes the local project file data from server
     */
    onLoadLocalFile: function () {
      var oView = this.getView();
      oView.setBusy(true);

      fetch('/api/fue')
        .then(function (res) {
          return res.json();
        })
        .then(function (res) {
          oView.setBusy(false);
          if (res.success && res.data) {
            this.updatePivotAndKpis(res.data);
            this.showSuccess("Datos recargados con éxito desde la ruta del proyecto.");
            this.onSearch(); // Re-apply search filters
          } else {
            this.showError("Error al cargar archivo local: " + (res.error || "Desconocido"));
          }
        }.bind(this))
        .catch(function (err) {
          oView.setBusy(false);
          this.showError("Error de conexión: " + err.message);
        }.bind(this));
    },

    /**
     * Saves current table data back to the FUE ABRIL.xlsx file on the server
     */
    onSaveLocalFile: function () {
      var oModel = this.getModel("fueModel");
      var aRecords = oModel.getProperty("/records") || [];
      var oView = this.getView();
      
      oView.setBusy(true);

      fetch('/api/fue', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ data: aRecords })
      })
      .then(function (res) {
        return res.json();
      })
      .then(function (res) {
        oView.setBusy(false);
        if (res.success) {
          this.showSuccess("Archivo FUE ABRIL.xlsx guardado con éxito en la ruta del proyecto.");
        } else {
          this.showError("Error al guardar en el servidor: " + res.error);
        }
      }.bind(this))
      .catch(function (err) {
        oView.setBusy(false);
        this.showError("Error de conexión: " + err.message);
      }.bind(this));
    },

    /**
     * Client-side excel uploader parsing using SheetJS
     */
    onImportExcel: function (oEvent) {
      var oFileUploader = this.byId("fileUploader");
      var oFile = oEvent.getParameter("files")[0];
      if (!oFile) return;
      
      this.getView().setBusy(true);

      var oReader = new FileReader();
      oReader.onload = function (e) {
        try {
          var data = new Uint8Array(e.target.result);
          /* global XLSX */
          var workbook = XLSX.read(data, { type: 'array' });
          var sheetName = workbook.SheetNames[0];
          var sheet = workbook.Sheets[sheetName];
          var rawData = XLSX.utils.sheet_to_json(sheet);
          
          if (rawData.length === 0) {
            throw new Error("El archivo está vacío o no contiene hojas válidas.");
          }
          
          // Map raw Excel properties to UI5 model keys
          var aMapped = rawData.map(function (row, idx) {
            return {
              id: idx + 1,
              Periodo: row['Periodo'] || 'Abril 2026',
              Usuarios: row['Usuarios'] || '',
              NombreCompleto: row['Nombre completo'] || '',
              Empresa: row['Empresa'] || '',
              TipoFue: row['Tipo FUE'] || '',
              Fue: typeof row['FUE'] === 'number' ? row['FUE'] : parseFloat(row['FUE']) || 0
            };
          });

          this.updatePivotAndKpis(aMapped);
          this.getView().setBusy(false);
          this.showSuccess("Importado: " + aMapped.length + " registros cargados. Haz clic en 'Guardar en Ruta Proyecto' para persistir.");
          oFileUploader.clear();
          this.onSearch();
        } catch (err) {
          this.getView().setBusy(false);
          this.showError("Error al analizar Excel: " + err.message);
          oFileUploader.clear();
        }
      }.bind(this);

      oReader.readAsArrayBuffer(oFile);
    },

    /**
     * Deletes a record from the model list
     */
    onDeleteRecord: function (oEvent) {
      var oItem = oEvent.getSource().getParent().getParent();
      var oContext = oItem.getBindingContext("fueModel");
      var oRecord = oContext.getObject();

      MessageBox.confirm("¿Estás seguro de eliminar el registro del usuario '" + oRecord.Usuarios + "'?", {
        title: "Confirmar eliminación",
        onClose: function (oAction) {
          if (oAction === MessageBox.Action.OK) {
            var oModel = this.getModel("fueModel");
            var aRecords = oModel.getProperty("/records") || [];
            
            // Filter out item
            var aNewRecords = aRecords.filter(function (rec) {
              return rec.id !== oRecord.id;
            });
            
            this.updatePivotAndKpis(aNewRecords);
            this.showSuccess("Registro eliminado.");
            this.onSearch();
          }
        }.bind(this)
      });
    },

    /**
     * Opens dialog to add a new record
     */
    onAddRecord: function () {
      this._openRecordDialog(null, false);
    },

    /**
     * Opens dialog to edit an existing record
     */
    onEditRecord: function (oEvent) {
      var oItem = oEvent.getSource().getParent().getParent();
      var oContext = oItem.getBindingContext("fueModel");
      var oRecord = oContext.getObject();
      this._openRecordDialog(oRecord, true);
    },

    /**
     * Helper to load and display the edit/add SimpleForm Dialog
     */
    _openRecordDialog: function (oRecord, bEdit) {
      var oModel = this.getModel("fueModel");
      var aRecords = oModel.getProperty("/records") || [];
      var oCurrentRecord = oRecord || {
        Periodo: oModel.getProperty("/kpis/period") || "Abril 2026",
        Usuarios: "",
        NombreCompleto: "",
        Empresa: "QUIMTIA PERU",
        TipoFue: "Advanced",
        Fue: 1
      };

      // Create Dialog inputs
      var oInpPeriod = new Input({ value: oCurrentRecord.Periodo });
      var oInpUser = new Input({ value: oCurrentRecord.Usuarios, editable: !bEdit });
      var oInpName = new Input({ value: oCurrentRecord.NombreCompleto });
      
      var oSelCompany = new Select({
        selectedKey: oCurrentRecord.Empresa,
        items: [
          new Item({ key: "IBEROPLAST SAC", text: "IBEROPLAST SAC" }),
          new Item({ key: "QUIMTIA ARGENTINA", text: "QUIMTIA ARGENTINA" }),
          new Item({ key: "QUIMTIA COLOMBIA", text: "QUIMTIA COLOMBIA" }),
          new Item({ key: "QUIMTIA HK", text: "QUIMTIA HK" }),
          new Item({ key: "QUIMTIA PERU", text: "QUIMTIA PERU" })
        ]
      });

      var oInpFueVal = new Input({ value: String(oCurrentRecord.Fue) });

      var oSelType = new Select({
        selectedKey: oCurrentRecord.TipoFue,
        change: function (oEvent) {
          var sType = oEvent.getParameter("selectedItem").getKey();
          if (sType === "Advanced") oInpFueVal.setValue("1");
          else if (sType === "Core") oInpFueVal.setValue("0.22");
          else if (sType === "Developer") oInpFueVal.setValue("1");
          else if (sType === "Self Service") oInpFueVal.setValue("0.1");
        },
        items: [
          new Item({ key: "Advanced", text: "Advanced" }),
          new Item({ key: "Core", text: "Core" }),
          new Item({ key: "Developer", text: "Developer" }),
          new Item({ key: "Self Service", text: "Self Service" })
        ]
      });

      var oDialog = new Dialog({
        title: bEdit ? "Editar Registro de FUE" : "Nuevo Registro de FUE",
        contentWidth: "420px",
        content: [
          new SimpleForm({
            editable: true,
            layout: "ResponsiveLayout",
            content: [
              new Label({ text: "Periodo", required: true }),
              oInpPeriod,
              
              new Label({ text: "Usuario (SAP ID)", required: true }),
              oInpUser,
              
              new Label({ text: "Nombre Completo", required: true }),
              oInpName,
              
              new Label({ text: "Empresa", required: true }),
              oSelCompany,
              
              new Label({ text: "Tipo FUE", required: true }),
              oSelType,
              
              new Label({ text: "Valor FUE", required: true }),
              oInpFueVal
            ]
          })
        ],
        beginButton: new Button({
          text: "Aceptar",
          type: "Accept",
          press: function () {
            // Validations
            var sPeriodVal = oInpPeriod.getValue().trim();
            var sUserVal = oInpUser.getValue().trim().toUpperCase();
            var sNameVal = oInpName.getValue().trim();
            var sCompanyVal = oSelCompany.getSelectedKey();
            var sTypeVal = oSelType.getSelectedKey();
            var nFueVal = parseFloat(oInpFueVal.getValue().trim()) || 0;

            if (!sPeriodVal || !sUserVal || !sNameVal) {
              MessageBox.warning("Por favor rellene los campos obligatorios.");
              return;
            }

            if (bEdit) {
              // Find index and update
              var idx = aRecords.findIndex(function (rec) {
                return rec.id === oCurrentRecord.id;
              });
              if (idx !== -1) {
                aRecords[idx].Periodo = sPeriodVal;
                aRecords[idx].NombreCompleto = sNameVal;
                aRecords[idx].Empresa = sCompanyVal;
                aRecords[idx].TipoFue = sTypeVal;
                aRecords[idx].Fue = nFueVal;
              }
            } else {
              // Generate new ID and append
              var maxId = aRecords.reduce(function (max, rec) {
                return rec.id > max ? rec.id : max;
              }, 0);
              aRecords.push({
                id: maxId + 1,
                Periodo: sPeriodVal,
                Usuarios: sUserVal,
                NombreCompleto: sNameVal,
                Empresa: sCompanyVal,
                TipoFue: sTypeVal,
                Fue: nFueVal
              });
            }

            this.updatePivotAndKpis(aRecords);
            this.showSuccess(bEdit ? "Registro actualizado." : "Registro creado.");
            this.onSearch();
            oDialog.close();
            oDialog.destroy();
          }.bind(this)
        }),
        endButton: new Button({
          text: "Cancelar",
          press: function () {
            oDialog.close();
            oDialog.destroy();
          }
        })
      });

      this.getView().addDependent(oDialog);
      oDialog.open();
    }

  });
});
