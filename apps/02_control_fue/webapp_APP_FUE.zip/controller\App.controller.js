sap.ui.define([
  "fue/control/controller/BaseController",
  "sap/ui/core/mvc/XMLView"
], function (BaseController, XMLView) {
  "use strict";

  var mViewMap = {
    "home":      "fue.control.view.Home",
    "dashboard": "fue.control.view.Dashboard",
    "fueList":   "fue.control.view.FUEList"
  };

  return BaseController.extend("fue.control.controller.App", {
    
    _oLoadedViews: {},

    onInit: function () {
      var oAppModel = this.getModel("app");
      
      // Load initial FUE data
      this._loadInitialData();

      // Subscribe to global navigation
      sap.ui.getCore().getEventBus().subscribe(
        "fue.control", "navigate", this._onNavigateEvent, this
      );

      // Navigate to home by default
      this._navigateTo("home");
    },

    onExit: function () {
      sap.ui.getCore().getEventBus().unsubscribe(
        "fue.control", "navigate", this._onNavigateEvent, this
      );
    },

    _onNavigateEvent: function (sChannel, sEvent, oData) {
      if (oData && oData.route) {
        this._navigateTo(oData.route);
        var oSideNav = this.byId("sideNav");
        if (oSideNav) {
          oSideNav.setSelectedKey(oData.route);
        }
      }
    },

    /**
     * Toggles the side navigation expansion
     */
    onToggleNav: function () {
      var oAppModel = this.getModel("app");
      var bExpanded = oAppModel.getProperty("/sideNavExpanded");
      oAppModel.setProperty("/sideNavExpanded", !bExpanded);
    },

    /**
     * Handles item selection in the SideNavigation
     */
    onNavSelect: function (oEvent) {
      var sKey = oEvent.getParameter("item").getKey();
      this._navigateTo(sKey);
    },

    /**
     * Performs view switching in the NavContainer
     * @param {string} sKey View key matching mViewMap
     */
    _navigateTo: function (sKey) {
      var sActualKey = sKey || "home";
      var oNavCont = this.byId("appNav");
      if (!oNavCont) return;

      if (this._oLoadedViews[sActualKey]) {
        oNavCont.to(this._oLoadedViews[sActualKey].getId());
        this.getModel("app").setProperty("/currentView", sActualKey);
        return;
      }

      var sViewName = mViewMap[sActualKey] || mViewMap["home"];
      oNavCont.setBusy(true);

      XMLView.create({ viewName: sViewName })
        .then(function (oView) {
          // Pass models explicitly
          oView.setModel(this.getOwnerComponent().getModel("i18n"), "i18n");
          oView.setModel(this.getOwnerComponent().getModel("app"), "app");
          oView.setModel(this.getOwnerComponent().getModel("fueModel"), "fueModel");

          this._oLoadedViews[sActualKey] = oView;
          oNavCont.setBusy(false);
          oNavCont.addPage(oView);
          oNavCont.to(oView.getId());
          this.getModel("app").setProperty("/currentView", sActualKey);
        }.bind(this))
        .catch(function (oErr) {
          oNavCont.setBusy(false);
          this.showError("Error cargando la vista: " + oErr.message);
          console.error("View load error:", oErr);
        }.bind(this));
    },

    /**
     * Loads FUE data from the backend
     */
    _loadInitialData: function () {
      var oNavCont = this.byId("appNav");
      if (oNavCont) oNavCont.setBusy(true);

      fetch('/api/fue')
        .then(function (res) {
          return res.json();
        })
        .then(function (res) {
          if (oNavCont) oNavCont.setBusy(false);
          if (res.success && res.data) {
            // Store raw records and run pivot aggregation
            this.updatePivotAndKpis(res.data);
          } else {
            this.showError("Error al cargar datos del servidor: " + (res.error || "Desconocido"));
          }
        }.bind(this))
        .catch(function (err) {
          if (oNavCont) oNavCont.setBusy(false);
          this.showError("Error de conexión al servidor: " + err.message);
          console.error("Fetch FUE error:", err);
        }.bind(this));
    }
  });
});
