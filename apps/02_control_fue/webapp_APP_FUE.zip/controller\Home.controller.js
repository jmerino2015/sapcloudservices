sap.ui.define([
  "fue/control/controller/BaseController"
], function (BaseController) {
  "use strict";

  return BaseController.extend("fue.control.controller.Home", {
    
    /**
     * Navigates to the Dashboard view
     */
    onNavToDashboard: function () {
      sap.ui.getCore().getEventBus().publish("fue.control", "navigate", { route: "dashboard" });
    },

    /**
     * Navigates to the FUE List view
     */
    onNavToFUEList: function () {
      sap.ui.getCore().getEventBus().publish("fue.control", "navigate", { route: "fueList" });
    },

  });
});
